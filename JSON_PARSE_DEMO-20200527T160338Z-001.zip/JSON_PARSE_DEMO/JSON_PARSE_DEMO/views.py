from django.shortcuts import render
from django.http import JsonResponse
import pandas as pd
import json 

def home(request):
    template = "home.html"
    data = pd.read_csv('/Json_Parse/JSON_PARSE_DEMO/JSON_PARSE_DEMO/data_info.csv')
    grp = data.groupby(['id','real_name','tz'])
    members = []
    for key, value in grp:
        dict_data = {}
        value.drop(['Unnamed: 0','id','real_name','tz'],axis = 1,inplace=True)
        activity_periods = value.to_json(orient='records')
        activity_periods = json.loads(activity_periods)
        dict_data["id"] = key[0]
        dict_data["real_name"] = key[1]
        dict_data["tz"] = key[2]
        dict_data["activity_periods"] = activity_periods
        members.append(dict_data)
    final_dict = {"ok" : "true","members":members}
    #return render(request,template,final_dict)
    return JsonResponse(final_dict)